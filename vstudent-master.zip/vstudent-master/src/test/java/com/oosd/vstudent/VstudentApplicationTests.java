package com.oosd.vstudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VstudentApplicationTests {

    @Test
    void contextLoads() {
    }

}
